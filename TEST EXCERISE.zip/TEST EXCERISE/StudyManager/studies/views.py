from django.shortcuts import render, redirect, get_object_or_404
from .models import Study
from .forms import StudyForm
import logging

# Logger setup
logger = logging.getLogger(__name__)

def home(request):
    return render(request, 'home.html')

def studylist(request):
    studies = Study.objects.all()
    return render(request, 'studylist.html', {'studies': studies})

def addstudy(request):
    if request.method == "POST":
        form = StudyForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('studylist')
    else:
        form = StudyForm()
    return render(request, 'study_form.html', {'form': form})

def viewstudy(request, study_id):
    study = get_object_or_404(Study, id=study_id)
    return render(request, 'studies/viewstudy.html', {'study': study})

def editstudy(request, study_id):
    study = get_object_or_404(Study, study_id=study_id)
    if request.method == "POST":
        form = StudyForm(request.POST, instance=study)
        if form.is_valid():
            form.save()
            logger.info("Study updated: %s", form.cleaned_data['study_name'])
            return redirect('studylist')
    else:
        form = StudyForm(instance=study)
    return render(request, 'studies/studydet.html', {'form': form})

def study_delete(request, study_id):
    study = get_object_or_404(Study, study_id=study_id)
    study.delete()
    logger.info("Study deleted: %s", study.study_name)
    return redirect('studylist')