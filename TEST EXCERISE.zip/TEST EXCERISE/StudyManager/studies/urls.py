from django.contrib import admin
from django.urls import path, include
from studies import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.studylist, name='home'),  # Root URL now points to the studylist view
    path('studylist/', views.studylist, name='studylist'),
    path('add/', views.addstudy, name='addstudy'),
    path('view/<int:study_id>/', views.viewstudy, name='viewstudy'),
    path('edit/<int:y>/', views.editstudy, name='editstudy'),
    path('delete/<int:z>/', views.study_delete, name='study_delete'),
]